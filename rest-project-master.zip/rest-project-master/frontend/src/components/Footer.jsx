import React from "react";

const Footer = () => {
  return (
    <footer>
      <div className="container">
        <div className="banner">
          <div className="left">Luxe Velvet Plate</div>
          <div className="right">
            <p>THANE </p>
            <p>Open:11.30-close:12.30</p>
          </div>
        </div>
        <div className="banner">
          <div className="left">
            <p>TEAM : Hansraj  Jagruti Bhagayshree</p>
          </div>
          <div className="right">
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;