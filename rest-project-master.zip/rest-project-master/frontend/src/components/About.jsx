import React from "react";
import { Link } from "react-router-dom";
import { HiOutlineArrowRight } from "react-icons/hi";

const About = () => {
  return (
    <>
      <section className="about" id="about">
        <div className="container">
          <div className="banner">
            <div className="top">
              <h1 className="heading">ABOUT US</h1>
              <p>The only thing we're serious about is food.</p>
            </div>
            <p className="mid">
             WE OFFER EXCEPTIONAL FOOD QUALITY BY USING FRESH, LOCALLY SOURCED INGREDIENTS AND MAINTAINING STRICT HYGIENE STANDARDS. THEIR DISHES ARE CRAFTED BY WORLD-CLASS CHEFS SPECIALIZING IN BOTH REGIONAL AND INTERNATIONAL CUISINES. THEY ENSURE PERSONALIZED DINING EXPERIENCES WITH OPTIONS FOR DIETARY PREFERENCES. THEY ARE ALSO COMMITTED TO SUSTAINABILITY BY SUPPORTING LOCAL FARMERS AND REDUCING FOOD WASTE. THIS DEDICATION TO QUALITY MAKES DINING A LUXURIOUS AND MEMORABLE EXPERIENCE.
            </p>
            <Link to={"/"}>
              Explore Menu{" "}
              <span>
                <HiOutlineArrowRight />
              </span>
            </Link>
          </div>
          <div className="banner">
            <img src="about.png" alt="about" />
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
