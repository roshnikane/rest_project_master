import mongoose from "mongoose";

export const dbConnection = async() => {
  console.log(process.env.MONGO_URI)

  try {
    const mongo_uri = `${process.env.MONGO_URI}/Hotels`
    const connectionInstance = await mongoose.connect(mongo_uri)
    console.log( `MONGO_DB connected at host :  ${connectionInstance.connection.host}`)

  } catch (error) {
    console.log(`Some error occured while connecing to database: ${error.message}`);
  }
};
